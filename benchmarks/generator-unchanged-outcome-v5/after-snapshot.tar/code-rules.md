# Code Generation Rules

Generated code remains a candidate until it passes `verification-rules.md`. The writer must not approve its own candidate, and a repair may not change the approved primary outcome, expected value, request proof, scenario count, or test enablement. Reuse repository-native commands and existing E2E rules; never add a dependency merely to verify generated code.

## Hard rules (always)

Non-negotiable for every generated spec, regardless of project shape:

- **`await` everything** — every `expect()` on a Locator and every Playwright action (`.click()`, `.fill()`, `.press()`, `.check()`, `.selectOption()`, `.hover()`). Missing `await` breaks test sequencing: the promise may still start, but its result is no longer ordered with the next step and a rejection may surface late as an unhandled rejection or after the test has ended.
- **Web-first assertions only** — `toBeVisible()`, `toHaveText()`, `toHaveURL()`, etc. Never `expect(await el.isVisible()).toBe(true)` (resolves once, no retry).
- **Control writes at their actual seam** — signup, login, payment, and other mutations must use the project's deterministic browser- or server-side test seam. A generated test never mutates real shared backend data.
- **Freeze network identity before exploration** — use one approved DNS address snapshot, pin every preflight peer, reject drift or mixed unsafe answers, and use the bundled executable preflight helper for special-address classification. The helper binds a root-owned absolute curl executable instead of ambient `PATH`, records its hash, and rejects credential-bearing or ambiguous queries before subprocess launch; ordinary non-secret route parameters may remain. A protected local route may prove reachability with matching peer-wide `401`/`403` or one non-followed same-origin redirect to a validated login URL; authenticate only afterward under the same guards. Live remote exploration is limited to an explicitly approved non-production target in an externally isolated controlled browser harness with enforceable egress. Shared, production, or unknown remote targets are snapshot-only. Sanitize user-provided snapshots from those targets by removing credentials, cookies, authentication/session tokens, sensitive query values, PII, customer data, secrets, and internal hostnames as appropriate; use stable placeholders and preserve only non-sensitive roles, names, labels, testids, and structure. Application-layer URL checks alone are not DNS-rebinding protection.
- **Credential values stay outside the agent context** — the user sets specifically named environment variables locally; the agent checks only presence and non-empty status and never requests, reads, prints, echoes, logs, or asks the user to paste a value.
- **Gate hydration** — on SSR/SSG apps, gate the first interaction on a hydration signal, never `waitForTimeout()` after `goto`.
- **One hard `expect()` per test** — a test built only from `expect.soft()` never fails early.

## Structure Detection

| What you find | What to generate |
|---------------|-----------------|
| POM directory exists, no POM for this page | New POM class (extends `BasePage` if present) + spec file |
| POM directory exists, POM for this page already exists | Extend existing POM — add new locators only + new spec file |
| No POM directory anywhere | Flat spec file only |

**Local POM style is authoritative:** For every new or modified POM, inspect relevant sibling POMs first. Match the safe dominant pattern for flat versus composed locators, getter methods versus direct `readonly` properties, base classes, constructors, and navigation naming—even when it differs from the fallback below. When styles are mixed, use the closest analogous POM already consumed by a spec and record that choice in the Step 4 plan. Use the fallback template below only when no safe local precedent exists; never copy a pattern that would violate the safety or verification contracts.

---

## Selector Priority (best → worst)

1. `getByRole('button', { name: 'Submit' })` — role + accessible name
2. `getByLabel('Email')` — form label — **only when the label/aria-label actually exists**; verify in the Step 3 snapshot before using
3. `getByPlaceholder('Email')` — only for an actual `placeholder` attribute
4. `getByTitle('Email')` — only for an actual `title` attribute; do not treat `title` as a placeholder
5. `getByTestId('submit-btn')` / `[data-testid="submit-btn"]` — explicit test hook
6. `getByText('Save')` / `.filter({ hasText: 'text' })` — visible text
7. attribute selector `[formControlName="email"]` — stable attribute
8. CSS `#id` / `.class` — last resort, `// JUSTIFIED:` required (see **Text-bearing elements without a role, label, or test id** below); stable structural attributes only, never styling classes
9. `.nth()` / `.first()` / `.last()` — **forbidden** without `// JUSTIFIED:` on the line above

**Project-configured test ids rank with role+name.** When the loaded Playwright config (Step 1) sets `use: { testIdAttribute: '...' }`, or `data-testid` (or the project's equivalent) is pervasive in the components under test, treat `getByTestId` as a **tier-1 locator alongside role+name** — not a fixed lower-tier fallback. A deliberate, stable test hook beats reaching past it for brittle text/placeholder locators. Keep `getByText`/`getByPlaceholder` as the fallback when no role or test id fits.

**Text-bearing elements without a role, label, or test id.** A counter, status line, badge, or list cell often has visible text but no role, label, or test id. Locate it by that text, `getByText('0 entries')` or an anchored pattern such as `getByText(/^\d+ entries?$/)`, or scope from a labeled ancestor, `getByRole('list', { name: 'Records' }).getByRole('listitem').filter({ hasText: 'Record 1' })`. Do not reach for `locator('#gb-count')` or `locator('.title')` because the element lacks a role: a behavior-preserving markup refactor renames ids and classes while roles, labels, and visible text stay, so an id or class selector fails exactly the refactor the test should survive. When the text may repeat, scope it with a role-based ancestor instead of `.nth()`. `#id` and `.class` selectors need `// JUSTIFIED: <reason>` on the line above, except when the project's Playwright config sets `testIdAttribute` to that attribute or its conventions doc documents the id or class scheme as the locator convention; record either exception in the Locator Mapping Table.

Never use XPath. Never use CSS class chains that couple to styling.

---

## Fallback POM rules (new files with no safe local precedent)

```typescript
import { Page, Locator } from '@playwright/test';

export class LoginPage {
  readonly form: {
    emailInput: Locator;
    passwordInput: Locator;
    submitButton: Locator;
  };
  readonly errorMessage: Locator;

  constructor(private page: Page) {
    this.form = {
      emailInput: page.getByLabel('Email'),
      passwordInput: page.getByLabel('Password'),
      submitButton: page.getByRole('button', { name: 'Sign in' }),
    };
    this.errorMessage = page.getByText('Invalid credentials');
  }

  async navigate() {
    await this.page.goto('/login');
  }
}
```

- Expose locators as direct `readonly` properties rather than getter methods
- Group related locators into named composition objects
- `navigate()` uses `page.goto(path)` unless a custom navigation utility exists in the project

---

## Spec Rules

```typescript
import { test, expect } from '@playwright/test';
import { LoginPage } from '../models/login-page';

test.describe('Login', () => {
  let loginPage: LoginPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    await loginPage.navigate();
  });

  test('should sign in with valid credentials', async ({ page }) => {
    // Given: user is on the login page (handled by beforeEach)

    // When: user fills in valid credentials and submits
    await loginPage.form.emailInput.fill(process.env.TEST_USER!);
    await loginPage.form.passwordInput.fill(process.env.TEST_PASSWORD!);
    await loginPage.form.submitButton.click();

    // Then: user is redirected to the dashboard
    await expect(page).toHaveURL('/dashboard');
  });

  test('should show error for invalid credentials', async () => {
    // Given: user is on the login page

    // When: user submits invalid credentials
    await loginPage.form.emailInput.fill('nonexistent@test.invalid');
    await loginPage.form.passwordInput.fill('wrongpassword');
    await loginPage.form.submitButton.click();

    // Then: error message is shown
    await expect(loginPage.errorMessage).toBeVisible();
  });
});
```

- Given/When/Then comments are optional: follow the repository's established test style, and use them only when that style or the approved plan calls for them.
- Each test fully independent — own storage, session, cookies
- `beforeEach` may perform shared navigation or isolated setup or reset that runs independently for every test; use it to create per-test state, never to share mutable state between tests.
- `afterEach` or fixture teardown may revert state the test itself wrote, as V5's disposable-state boundary requires; never use it to hide a failure
- Mock external APIs with Playwright Network API; do not call real third-party services
- **Use a web-first assertion that matches the approved product contract:** `toBeVisible()`, `toBeHidden()`, `toBeAttached()`, `toHaveText()`, `toContainText()`, `toHaveCount()`, `toHaveURL()`, and equivalent retrying matchers.
- Use `expect.soft()` for independent, non-critical checks — but ensure at least one hard `expect()` gates on the primary condition per test. A test with only `expect.soft()` assertions never fails early.

**Forbidden:**

> Maintenance: the rules below (and the mirrored entries elsewhere in this file) duplicate e2e-reviewer patterns for generation-time convenience. Pattern semantics — IDs, severities, false-positive exclusions — are owned by `skills/e2e-reviewer/references/pattern-reference.md`; on conflict, that file wins.

| Forbidden | Use instead |
|-----------|-------------|
| `waitForTimeout(N)` | `await expect(el).toBeVisible({ timeout: N })` |
| `expect(await el.isVisible()).toBe(true)` | `await expect(el).toBeVisible()` |
| `const n = await el.count()` as the sole outcome assertion or readiness gate | `await expect(el).toHaveCount(N)` when cardinality is the contract, or another web-first assertion for the promised user-visible postcondition. Raw `count()` remains valid for evidenced data collection or bounded iteration after readiness when a separate web-first assertion proves the outcome. |
| `toBeAttached()` when the approved contract promises visibility or removal | Match the promise: use `toBeVisible()` for visibility and `not.toBeAttached()` for removal. Positive `toBeAttached()` is valid when DOM attachment itself is the approved contract, including a CSS-hidden element that must persist or an app-provided hydration marker. |
| `expect(locator).toBeTruthy()` | Replace it with a web-first matcher that expresses the approved contract: `toBeVisible()` only for promised visibility, `toBeAttached()` for promised DOM presence (including a CSS-hidden element), or another matching outcome assertion. Locator is always a truthy JS object, so the original assertion does not reveal intent. Do not infer visibility from the invalid truthiness assertion or change the approved expected value. |
| `page.click(selector)` / `page.fill(selector, v)` | `page.locator(selector).click()` / `.fill(v)` — locator-first actions are easier to compose and review |
| `{ force: true }` | Fix the root cause (element not actionable); if unavoidable, add `// JUSTIFIED:` |
| `waitUntil: 'networkidle'` | `waitUntil: 'domcontentloaded'` or condition-based wait — unreliable on SPAs |
| `expect(page.url()).toContain(x)` | `await expect.poll(() => page.url()).toContain(x)` — preserves substring semantics and retries |
| Framework component selectors in spec (`app-button`, `my-component`) | POM only |
| XPath selectors | `getByRole` / `getByLabel` / `getByTestId` |

**Await rule:** Every `expect()` on a Locator and every Playwright action (`.click()`, `.fill()`, `.type()`, `.press()`, `.check()`, `.selectOption()`, `.hover()`) **must** be `await`ed. Missing `await` breaks test sequencing; the operation can still run, but its rejection may be unhandled, reported after the test ends, or race the following step.

---

**Absence after a failed write.** When a scenario proves that a rejected write stored nothing, reload or wait for the re-fetch that reads the stored state before asserting the absence, as `verification-rules.md` V4 requires; asserting it on a view that the failure did not refresh passes even when the server stored the data.

**Secondary outcome placement.** A selected secondary outcome is an extra assertion placed after the primary assertion in the same test, so a V2 or V3 fault turns the run red at the primary first; an assertion that also serves as the V2 settled-state gate stays before the primary and counts as that secondary outcome.

## Network Determinism

Decide per endpoint, not per suite:

| Traffic | Strategy |
|---------|----------|
| **Writes / credential paths** (signup, login, payment, any mutation) | Control each write at the seam where it originates. Use `page.route()` for browser-originated requests and the project's server-side test double, test API, or E2E-only boundary for SSR/RSC/BFF traffic. Never create real accounts, hit real payment providers, or mutate shared backend data. |
| Stable first-party reads | Real backend acceptable when responses are deterministic enough to assert on |
| Third-party services | Always stub (also covered by Spec Rules above) |
| Real-backend smoke | At most one small, clearly named smoke spec may exercise the real backend end-to-end (e.g. a throwaway guest session) — keep it isolated |

When the app funnels API calls through a proxy endpoint (e.g. `/api/request?cmd=<path>`), write ONE shared route-mock helper that matches on the decoded routing parameter and exposes response builders — not per-test `page.route()` calls with duplicated URL parsing:

```typescript
// helpers/mockApi.ts — match on the decoded routing param; unlisted calls fall through
await page.route('**/api/request?**', route => {
  const cmd = decodeCmd(route.request().url());
  const hit = map[cmd];
  return hit
    ? route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(hit) })
    : route.continue();
});
```

Fall-through (`route.continue()`) keeps reads real, but it means **a misspelled key silently leaks a write to the real backend** — list every write endpoint explicitly, and record that requirement in the project's conventions doc (Step 5b).

**The mock layer is decided by where the call originates, not just the URL.** `page.route()` only intercepts requests the *browser* makes. Calls issued server-side — Next.js SSR/RSC, route handlers, a BFF, `getServerSideProps` — never pass through the browser, so a `page.route()` mock silently misses them and the test hits the real backend (the same root cause as the cookie note under Auth & Session). For server-originated traffic, mock at a server-side seam instead: an E2E-only env var that flips the server's fetch boundary to fixed responses (`process.env.E2E_MOCK` → return canned payloads), or the project's existing test double. Detect the origin before choosing: if the data appears in the initial SSR HTML (view-source), it's a server call and `page.route()` won't help.

**Request-aware rules.** When the same endpoint must answer differently by method or parameters (tab filters, pagination pages, POST toggles), extend the helper with an ordered rule list instead of sprinkling conditional logic in specs:

```typescript
type MockRule = {
  when?: { method?: string; params?: Record<string, string> };
  response: { status?: number; body: unknown };
};
// map value: single response (back-compat) OR MockRule[] — first match wins.
// params compare only the listed keys: URL query for GET/DELETE,
// urlencoded body for POST (body value wins if a key exists in both).
```

Request-aware guidance:

- **A registered-but-unmatched rule array must NOT fall through or look successful.** If the cmd is in the map but no rule matches, abort that request so it cannot reach any external network and also cause an unconditional hard test failure that includes the method and parameters, even when the UI handles the failed request. Use the repository's native mechanism; for example, a per-test collector checked by a hard fixture teardown or `afterEach`. Aborting alone is insufficient because the application may render a normal fallback state. A param typo (`liked: 'True'`) must remain observable as a test failure.
- Pagination contracts become testable with a `start`/`offset` param rule per page: seed page 1 at exactly the page size (a short page often sets an internal "loaded end" flag that suppresses the next request), then assert the page-2 item appears after scroll *and* a page-1 item is still attached (append, not replace).
- **Before narrowing a rule with `when.params`, prove the app actually sends that param at that point in time — wire evidence, not source intent.** A component that reads `router.query` in a first-render `useRef`/initializer can fire its initial fetch during hydration before `router.isReady`, so the query parameter is absent from the wire even though the source appears to pass it. If the approved scenario or V4 proof requires that parameter, do not broaden the rule, remove its parameter, or replace request proof with a pixel assertion; return `NOFIX` with the product-defect evidence and require an approved plan change before weakening the contract. A broad rule is acceptable only when the approved contract never required that parameter and the observed wire behavior supports the broader match.

**Prove the call, not just the pixels.** For write interactions with optimistic UI (like toggles, deletes), the UI updates before — and regardless of — the request. Pair every such assertion with request proof:

```typescript
const call = page.waitForRequest(r => r.method() === 'POST' && r.url().includes('cmd=%2Fv2%2Fuser%2Fsentence%2Flike'));
await likeToggle.click();
await call; // without this line the test passes even if the wiring to the API is deleted
await expect(likeToggle).toHaveAttribute('aria-pressed', 'true');
```

**…but prove the call HAPPENS before asserting it (the inverse trap).** Unmount-cleanup API calls are a common counterexample: an empty-deps effect's cleanup can capture its guard variables as a stale closure from mount time, leaving the call unreachable even though the source reads as an intended contract. Before shipping call proof on exit, unmount, or cleanup paths, verify the request fires at least once with a solo run or network log. If an approved scenario or V4 contract requires the call and it never occurs, return `NOFIX` with the product-defect evidence; do not replace that proof with a user-visible assertion. Only use a UI-only assertion when the approved contract never required that call, and record V4 as `N/A` only where the verification rules permit it.

---

## SSR & Hydration

- **Gate the first interaction on hydration for server-rendered apps** (Next.js, Nuxt, SvelteKit, Astro, Remix). SSR paints interactive-looking elements before the framework attaches event listeners; Playwright's actionability checks pass against that inert DOM, so the first click is reported successful but does nothing and the spec fails at the *next* assertion — intermittently, because hydration sometimes wins the race. Detect SSR from the framework config/`package.json` before generating.
- Preferred gate, in order:
  1. An app-provided hydration marker: `await expect(page.locator('html[data-hydrated]')).toBeAttached();` — if the app exposes none, propose the one-line marker upstream (set an attribute in a root `useEffect`/`onMounted`); it fixes every spec at once.
  2. A self-verifying first action only when every retry is proven idempotent: `await expect(async () => { await openButton.click(); await expect(dialog).toBeVisible({ timeout: 1000 }); }).toPass();`. Record the idempotence evidence; the example is not permission to retry an arbitrary click.
- **Never retry a non-idempotent action** such as submit, delete, payment, purchase, or message send as hydration recovery unless idempotence is proven at the system boundary (for example, a verified idempotency key or a disposable backend reset between attempts). If the first action's outcome is uncertain, establish a clean state and a hydration marker before one fresh attempt; otherwise stop rather than risk a duplicate write.
- Never `page.waitForTimeout()` after `goto` as a hydration guard — it's the #9 band-aid the reviewer flags, and it still races on slow CI.
- Nuance: Qwik apps are resumable, not hydrated — no page-global gate needed. Island frameworks (Astro) hydrate per-island according to their `client:*` directive — gate on the specific island's readiness (its own marker or a self-verifying action on that island), not a page-global signal.

---

## Auth & Session

- Authenticate **once**, programmatically (API-login helper or a `setup` project), persist with `storageState`, reuse it in specs that need a session. UI-driven login belongs only in specs that test the login flow itself.
- Never hard-depend on a **manually captured** session file — a locally generated `auth/*.json` that a fresh clone or CI won't have, and that silently expires. Generated tests must be able to recreate their session from code.
- Logged-out scenarios use a fresh context (no `storageState`) — don't "log out first" inside a test.
- **Login-success flows: route mocks can't mint cookies.** Session cookies are usually issued server-side (the app server proxies the login call and sets cookies from the backend response); a browser-layer route mock returns the success body but no `Set-Cookie`, so the post-login SSR still sees an anonymous user. Hybrid pattern: mock the login POST for the form/UX behavior, seed the session cookies through the project's sanctioned test seam (test-auth endpoint, API login helper) right before submit, then assert the full redirect chain. Comment WHY in the spec — it reads like cheating until you know cookie issuance is server-side.

---

## Branch State Seeding

- For multi-step funnels (onboarding, checkout, multi-page applications), do **not** drive the shared prefix (consent → phone-auth → …) through the UI in every spec. Each test re-running the common steps is slow, and one change to the prefix breaks every downstream test at once — the opposite of the independence Playwright recommends.
- Instead, seed the user to the **branch's starting state** through a test-only API/endpoint, then exercise only the branch under test. This mirrors the `storageState` approach for auth, extended to application state.
- Use real UI steps for the prefix **only** in the one spec that specifically verifies that prefix. Everywhere else, seed and skip ahead.
- Record which seeding endpoints/fixtures exist in the project's conventions doc (Step 5b) so later runs reuse them instead of re-driving the funnel.

---

## YAGNI audit (run immediately after writing code)

1. List every locator defined in the generated/modified POM file(s).
2. Search each locator name across the relevant specs, POMs, and test
   utilities/helpers. Include same-file and cross-file internal method usage;
   a spec may call a POM method without referencing its locator property
   directly.
3. Delete a locator only when that complete search finds zero usages. Never
   delete a locator used by a POM or utility method merely because no spec
   references the locator property directly.
4. Output the audit table:

```
| Locator        | File           | Used in          | Status  |
|----------------|----------------|------------------|---------|
| submitButton   | login-page.ts  | login.spec.ts:18 | IN USE  |
| unusedLocator  | login-page.ts  | (none)           | DELETED |
```

## Suppression Convention

When a forbidden pattern is genuinely unavoidable, add `// JUSTIFIED: <reason>` on the **line immediately above**. This tells the `e2e-reviewer` to skip the hit during grep checks.

Patterns that accept `// JUSTIFIED:`:
- `.nth()` / `.first()` / `.last()` — explain why positional selection is required
- `#id` / `.class` selectors — explain why no role, label, test id, or visible text locates the element
- `{ force: true }` — explain why the element is not normally actionable
- `{ timeout: 0 }` — explain why the assertion should share the enclosing test deadline instead of having a finite local bound
- `evaluate()` / `waitForFunction()` with raw DOM — explain why the framework API can't express the condition

**No suppression exists for:** `test.only` / `it.only` (always remove before commit).
